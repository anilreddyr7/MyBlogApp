//Class that is responsible for storing posts
export default class Model{

    constructor(){
        this.posts = [
            {id:1,text:"sample data 1",title:"post 1",timestamp:"4/7/2021, 6:37:39 PM"},
            {id:2,text:"sample data 2",title:"post 2",timestamp:"4/7/2021, 6:37:40 PM"}
        ]
    }

    addPost(postData){
        const newPost = {
            id: this.posts.length > 0 ? this.posts[this.posts.length - 1].id + 1 : 1,
            text: postData['text'],
            title: postData['title'],
            timestamp: new Date().toLocaleString()
          }

        this.posts.push(newPost);
        this._commit(this.posts);
    }

    editPost(postData){
        this.posts = this.posts.map((post) => 
        post.id === id ? {id:post.id,text: postData['text'],title: postData['title'],timestamp: new Date().getTime().toString()}:post)
    }

    bindPostsChanged(callBack){
        this.onPostsChanged = callBack;
    }
    
    _commit(posts){
        this.onPostsChanged(posts);
    }
}