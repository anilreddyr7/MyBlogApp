import {html} from "../templatelib/templatehelper.js";
import CustomElement from "./CustomElement.js";
import {SERVICE_END_POINT_URL} from "../util/constants.js";

export default class ArticlesList extends CustomElement{
    constructor(){
        super();
        this._listOfPosts = [];
    }

    async getPosts() {
        return await fetch(SERVICE_END_POINT_URL).then(res => res.json())
     }

    set posts(dataObj){
        this._listOfPosts = dataObj;
        let element = this.getElement();
        let el = this.shadowRoot.querySelector('#content');
        el.appendChild(element);
    }

    async getElement(){
        const element = await this.render();
        return element;
    }

    get posts(){
        return this._listOfPosts;
    }

    open(id) {
        this.router.navigate(`/post/${id}`)
    }

    editPost(post){
        this.router.navigate(`/post/${post.id}/edit`)
    }

    async render() {
        const posts = await this.getPosts()
        return html`<section id="posts-container">
                        ${posts.map((post) => {
                            return html`<div class="post">
                                                <div onclick=${this.open.bind(this, post.id)}>
                                                <h2 class="post-title">${post.title}</h3>
                                                <p class="post-body">${post.text}</p>
                                                </div>
                                                <div class="post-controls">
                                                <button onclick=${this.editPost.bind(this,post)}>Edit</button>
                                                <button>Delete</button>
                                                </div>
                                        </div>`
                         })}
                    </section>`
    }
}