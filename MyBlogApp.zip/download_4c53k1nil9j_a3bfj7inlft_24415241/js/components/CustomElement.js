
export default class CustomElement extends HTMLElement {

    //Connected call back method for custom element
    async connectedCallback() {
        const element = await this.render();
        this.appendChild(element);
    }
}
