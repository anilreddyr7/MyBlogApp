import {html} from "../templatelib/templatehelper.js";
import CustomElement from "./CustomElement.js";
import {SERVICE_END_POINT_URL} from "../util/constants.js";

export default class Article extends CustomElement{
    //
    async getArticleData() {
       return await fetch(`${SERVICE_END_POINT_URL+this.postID}`).then(res => res.json())
    }

    async render() {
        if(this.isEdit){
         return html`<section id="post-container">
            <input type="text" value=${this.title}></input>
            <textarea>${this.text}</textarea>
            <div class="post-controls"><button onclick=''>Update</button></div>
        </section>`
        }
        const {title, text} = await this.getArticleData()
        return html`<section id="post-container">
                        <h2>${title}</h2>
                        <p>${text}</p>
                    </section>`
    }
}