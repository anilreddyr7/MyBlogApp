/**
 * Constants used for different purposes
 */
export const SERVICE_END_POINT_URL='https://salesforce-blogs.herokuapp.com/blogs/api/';