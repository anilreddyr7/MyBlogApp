/**
 * The view class which is completely isolated from model. It holds custom elements for blog posts and view post data.
 */
import * as component from "../components/index.js";
import {html} from "../templatelib/templatehelper.js";

export default class view{
    
    constructor(router){      
        for (let key in component) {
            //Add app router to custom components
            component[key].prototype.router = router;   
            //Register custom elements
            customElements.define(`${key}-element`, component[key]);
        }

    }

    createElement(tag, className){
        const element = document.createElement(tag);
        if(className) element.classList.add(className);
        return element;
    }

    getElement(selector){
        const element = document.querySelector(selector);
        return element;
    }

    get _getPostDetails(){
        const postObj={};
        return postObj;
    }

    invokePostClick(id){
        console.log(""+id);
    }

    displayPosts(){
            const element = html`<articleslist-element id="root"></articleslist-element>`;
            document.querySelector("#blogarticlesdiv").replaceWith(element);
    }

    openSpecificPost(id){
        const element = html`<article-element id="root"></article-element>`;
        element.postID = id
        document.querySelector("#root").replaceWith(element);
    }
    
    editSpecificPost(id){
        const element = html`<article-element id="root"></article-element>`;
        element.postID = id;
        element.isEdit = true;
        element.title = "sample title";
        element.text = "sample text";
        document.querySelector("#root").replaceWith(element);
    }

    bindAddPost(handler){
       /* this.submitButton.addEventListener('click', event => {
           // event.preventDefault();
            let postObj={};
            postObj['title'] = this.inputTitle.value;
            postObj['text'] = this.inputPost.value;
            postObj['timestamp'] = new Date().getTime().toString();
            handler(postObj);
           // if()
        })*/
    }
   
}

 