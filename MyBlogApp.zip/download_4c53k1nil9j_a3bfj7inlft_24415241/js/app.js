import Controller from "./controller/appcontroller.js";
import Model from './model/appmodel.js';
import View from './view/appview.js';
import Router from './router/approuter.js';

//Creating router to capture view changes
const router = new Router();
const appController = new Controller(new Model(),new View(router));
// Register routes
router.on("/", () => {
    appController.invokeActiontoShowPosts();
  });
router.on("/post/:id", params => {
    appController.openSpecificPost(params.id);
  });
router.on("/post/:id/edit",params => {
    appController.editSpecificPost(params.id);
});
//Resolving router
router.resolve();