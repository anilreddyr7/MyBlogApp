/**
 * Controller class which isolates model and view. Here, model and view bindings are registered.
 */
export default class Controller{
    constructor(model, view){
        this.model = model;
        this.view = view;

        this.model.bindPostsChanged(this.onPostsListChanged);
        this.view.bindAddPost(this.handleAddPost);
    }

    onPostsListChanged = (posts) => {
        this.view.displayPosts(posts)
    }

    handleAddPost = (post) => {
        this.model.addPost(post);
    }

    invokeActiontoShowPosts = () => {
         //Display initial posts
         this.onPostsListChanged(this.model.posts);
    }
    openSpecificPost = (id) => {
        this.view.openSpecificPost(id)
    }

    editSpecificPost = (id) => {
        this.view.editSpecificPost(id)
    }
}