Name: Anil Ramini, Email Address: raminianilreddy@gmail.com

##Design approach - 

I wanted to go with vanilla javascript to build single page application and wanted to showcase how I can leverage existing native javascript features to create framework like architecture similar to react, backbone js.

Started with MVC pattern where model is completely isolated from view. Hence only controller binds model and view to events. View is consolidated with custom elements (web components). As of now, created 2 custom components - list of articles, article. We can leverage these 2 components for viewing list of posts, edit existing post and create new post.

But as of now, I am facing some challenges in passing data as an object between custom components, hence maintained state logic with in custom element code. This can be fixed and decouple the entire model logic from view components.

Patterns used- Module pattern (ES6 modules), MVC pattern for entire application and component reuse using custom components

##List of browsers tested - Google Chrome, Mozilla Firefox
##Libraries used - 
1. Open source template literal to DOM node conversion library (Hyper text literal) - https://observablehq.com/@observablehq/htl  - As javascript support template literals to display dynamic data, it is some what tedious to manage the concatanation etc. Hence used this open source library to create DOM object out of given html template literals like JSX.

2. Navigo router for vanilla javascript - https://github.com/krasimir/navigo/blob/master/README_v7.md
As it is single page application, we need to store the view changes and show them via url paths. This can be achived using router concept.

##List of source files - 
index.html - single page of entrypoint
app.js - Main js file which is included in index.html 
approuter.js - Navigo router implementation code (copied from Navigo repo)
appcontroller.js - Holds Controller code which is invoked from app.js
appmodel.js - Holds model related data which talks to service end points
appview.js - View components related code which referneces 2 custom components
components/*.js - these are related to custom web components to display the data
templatehelper.js - This is the hyper text literal implementation code copied from HTL repo.
constants.js - Holds end point value 
styles.css - styles related code

##Other comments and incomplete work- 

I could able to complete view list of posts, view specific post and edit related UI. I felt, the entire architecture was good and faced some issues while building app. Hence could not able to do it with in 3 hours time. But I'm confident on the entire design and remaining work. Also, it is development version and need to minify, bundle the scripts using webpack or rollup. 
Couldn't get much time to do styling related work.